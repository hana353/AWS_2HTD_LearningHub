// src/services/test.service.js
// Logic cho module bài kiểm tra
// S3 service
import { uploadFileToS3 } from './s3.service.js';
import {
  createQuestion,
  getQuestionsByAuthor,
  getQuestionById,
  updateQuestionById,
  deleteQuestionById
} from '../models/question.model.js';

import {
  createExam,
  getExamDetail,
  getExamsByCreator,
  updateExam,
  setExamPublished,
  deleteExamById,
  getPublishedExamsForUser
} from '../models/exam.model.js';

import {
  createSubmission,
  getSubmissionById,
  saveSubmissionGrading,
  getSubmissionsByUser,
  getSubmissionWithDetails
} from '../models/submission.model.js';

import {
  createNotification,
  createNotificationsForUsers
} from './notification.service.js';
import { sql, getPool } from '../config/db.js';

// ============================
// Helper chung
// ============================

// Parse JSON choices / tags cho tất cả câu hỏi trong 1 exam
function parseExamQuestions(exam) {
  if (!exam || !Array.isArray(exam.questions)) return exam;

  exam.questions = exam.questions.map((q) => ({
    ...q,
    choices: q.choices ? JSON.parse(q.choices) : null,
    tags: q.tags ? JSON.parse(q.tags) : null
  }));

  return exam;
}

// ============================
// Helper upload media cho câu hỏi
// ============================

// Chuyển base64 (hoặc data URL) -> Buffer
function base64ToBuffer(dataUrlOrBase64) {
  if (!dataUrlOrBase64) return null;

  const base64 = dataUrlOrBase64.includes('base64,')
    ? dataUrlOrBase64.split('base64,')[1]
    : dataUrlOrBase64;

  return Buffer.from(base64, 'base64');
}

/**
 * imageFile / audioFile dự kiến dạng:
 * {
 *   base64: 'data:image/png;base64,...' hoặc chỉ chuỗi base64,
 *   filename: 'q1.png',
 *   contentType: 'image/png'
 * }
 */
async function uploadQuestionMedia({
  imageFile,
  audioFile,
  existingImageKey = null,
  existingAudioKey = null
}) {
  let imageS3Key = existingImageKey || null;
  let audioS3Key = existingAudioKey || null;

  // Ảnh câu hỏi
  if (imageFile?.base64) {
    const buffer = base64ToBuffer(imageFile.base64);
    const { key } = await uploadFileToS3(
      buffer,
      'questions/images', // prefix trong S3
      imageFile.filename || 'question-image',
      imageFile.contentType || 'image/png'
    );
    imageS3Key = key;
  }

  // Audio câu hỏi
  if (audioFile?.base64) {
    const buffer = base64ToBuffer(audioFile.base64);
    const { key } = await uploadFileToS3(
      buffer,
      'questions/audios',
      audioFile.filename || 'question-audio',
      audioFile.contentType || 'audio/mpeg'
    );
    audioS3Key = key;
  }

  return { imageS3Key, audioS3Key };
}

// Map 1 dòng exam_questions + questions thành object trả cho FE
function mapExamQuestionRow(q) {
  const choices =
    typeof q.choices === 'string' && q.choices
      ? JSON.parse(q.choices)
      : q.choices || null;

  const tags =
    typeof q.tags === 'string' && q.tags
      ? JSON.parse(q.tags)
      : q.tags || null;

  return {
    questionId: q.question_id ?? q.questionId ?? q.id,
    title: q.title,
    body: q.body,
    type: q.type,
    difficulty: q.difficulty,
    choices,
    tags,
    imageS3Key: q.image_s3_key || null, // NEW
    audioS3Key: q.audio_s3_key || null, // NEW
    points: Number(q.points ?? 1),
    sequence: q.sequence
  };
}

// Build response chung cho các API về câu hỏi trong đề thi
function buildExamQuestionsResponse(exam, questionList = []) {
  return {
    examId: exam.id,
    examTitle: exam.title,
    examDescription: exam.description,
    durationMinutes: exam.duration_minutes,
    passingScore: exam.passing_score,
    randomizeQuestions: exam.randomize_questions,
    published: exam.published,
    createdAt: exam.created_at,
    updatedAt: exam.updated_at,
    questions: questionList
  };
}

// ============================
// PHẦN GIÁO VIÊN / ADMIN
// ============================

// ---------- CÂU HỎI (bank dùng chung, hiện chủ yếu tái sử dụng cho exam) ----------

// Tạo câu hỏi cho giáo viên
export async function createTeacherQuestion(teacherId, payload) {
  const {
    title,
    body,
    type,
    choices,
    difficulty,
    tags,
    imageFile, // NEW
    audioFile  // NEW
  } = payload;

  // 1. Upload media lên S3
  const { imageS3Key, audioS3Key } = await uploadQuestionMedia({
    imageFile,
    audioFile
  });

  // 2. Serialize choices/tags
  const choicesJson = choices ? JSON.stringify(choices) : null;
  const tagsJson = tags ? JSON.stringify(tags) : null;

  // 3. Tạo question, lưu luôn S3 key (bạn nhớ đã thêm 2 cột image_s3_key, audio_s3_key trong DB nhé)
  const question = await createQuestion({
    authorId: teacherId,
    title,
    body,
    type,
    choicesJson,
    difficulty,
    tagsJson,
    imageS3Key,   // NEW
    audioS3Key    // NEW
  });

  // 4. Parse lại choices/tags cho FE như cũ
  if (question.choices) {
    question.choices = JSON.parse(question.choices);
  }
  if (question.tags) {
    question.tags = JSON.parse(question.tags);
  }

  return question;
}

// Lấy danh sách câu hỏi của giáo viên (bank)
export async function listTeacherQuestions(
  teacherId,
  { search, type, page, pageSize }
) {
  const questions = await getQuestionsByAuthor({
    authorId: teacherId,
    search,
    type,
    page,
    pageSize
  });

  return questions.map((q) => ({
    ...q,
    choices: q.choices ? JSON.parse(q.choices) : null,
    tags: q.tags ? JSON.parse(q.tags) : null
  }));
}

// Lấy chi tiết 1 câu hỏi của giáo viên (bank)
export async function getTeacherQuestionDetail(teacherId, questionId) {
  const question = await getQuestionById(questionId);

  // Không tồn tại
  if (!question) {
    const err = new Error('Question not found');
    err.status = 404;
    throw err;
  }

  // chỉ cho xem câu hỏi của chính mình
  if (
    String(question.author_id).toLowerCase() !==
    String(teacherId).toLowerCase()
  ) {
    const err = new Error('You are not allowed to view this question');
    err.status = 403;
    throw err;
  }

  return {
    ...question,
    choices: question.choices ? JSON.parse(question.choices) : null,
    tags: question.tags ? JSON.parse(question.tags) : null
  };
}

// Cập nhật câu hỏi (bank)
export async function updateTeacherQuestion(teacherId, questionId, payload) {
  // Lấy câu hỏi hiện tại & check quyền
  const existing = await getTeacherQuestionDetail(teacherId, questionId);

  const {
    choices,
    tags,
    imageFile, // NEW
    audioFile, // NEW
    ...rest
  } = payload;

  const choicesJson = choices ? JSON.stringify(choices) : null;
  const tagsJson = tags ? JSON.stringify(tags) : null;

  // Upload media mới (nếu có), nếu không giữ key cũ
  const { imageS3Key, audioS3Key } = await uploadQuestionMedia({
    imageFile,
    audioFile,
    existingImageKey: existing.image_s3_key,
    existingAudioKey: existing.audio_s3_key
  });

  const updated = await updateQuestionById(questionId, {
    ...rest,
    choicesJson,
    tagsJson,
    imageS3Key,
    audioS3Key
  });

  if (!updated) {
    const err = new Error('Question not found');
    err.status = 404;
    throw err;
  }

  return {
    ...updated,
    choices: updated.choices ? JSON.parse(updated.choices) : null,
    tags: updated.tags ? JSON.parse(updated.tags) : null
  };
}

// Xoá câu hỏi (bank)
export async function deleteTeacherQuestion(teacherId, questionId) {
  // Check quyền + tồn tại
  await getTeacherQuestionDetail(teacherId, questionId);

  await deleteQuestionById(questionId);
}

// ---------- ĐỀ THI ----------

// ====== CÂU HỎI TRONG 1 EXAM (luồng mới) ======
async function ensureExamOwnedByTeacher(teacherId, examId) {
  const exam = await getExamDetail(examId);
  if (!exam) {
    const err = new Error('Exam not found');
    err.status = 404;
    throw err;
  }

  if (
    String(exam.created_by).toLowerCase() !==
    String(teacherId).toLowerCase()
  ) {
    const err = new Error('You are not allowed to modify this exam');
    err.status = 403;
    throw err;
  }

  return exam;
}

// Tạo câu hỏi và gắn vào 1 exam
export async function createQuestionInExam(teacherId, examId, payload) {
  const exam = await ensureExamOwnedByTeacher(teacherId, examId);

  const question = await createTeacherQuestion(teacherId, payload);

  const pool = await getPool();
  const request = pool.request();

  request.input('exam_id', sql.UniqueIdentifier, examId);
  request.input('question_id', sql.UniqueIdentifier, question.id);
  request.input(
    'points',
    sql.Decimal(6, 2),
    payload.points != null ? payload.points : 1
  );
  request.input(
    'sequence',
    sql.Int,
    payload.sequence != null ? payload.sequence : 0
  );

  const result = await request.query(`
    INSERT INTO exam_questions (exam_id, question_id, points, sequence)
    OUTPUT inserted.*
    VALUES (@exam_id, @question_id, @points, @sequence);
  `);

  const eq = result.recordset[0];

  const parsedChoices = question.choices
  ? JSON.parse(question.choices)
  : null;
const parsedTags = question.tags
  ? JSON.parse(question.tags)
  : null;

const questionItem = {
  questionId: question.id,
  title: question.title,
  body: question.body,
  type: question.type,
  difficulty: question.difficulty,
  choices: parsedChoices,
  tags: parsedTags,
  points: Number(eq.points ?? 1),
  sequence: eq.sequence
  };

  return buildExamQuestionsResponse(exam, [questionItem]);
}


// Lấy danh sách câu hỏi trong 1 exam (GV)
export async function listQuestionsInExam(teacherId, examId) {
  const exam = await ensureExamOwnedByTeacher(teacherId, examId);

  const pool = await getPool();
  const request = pool.request();
  request.input('exam_id', sql.UniqueIdentifier, examId);

  const result = await request.query(`
    SELECT
      eq.id              AS exam_question_id,
      eq.exam_id,
      eq.question_id,
      eq.points,
      eq.sequence,
      q.title,
      q.body,
      q.type,
      q.difficulty,
      q.choices,
      q.tags,
      q.image_s3_key,
      q.audio_s3_key  
    FROM exam_questions eq
    JOIN questions q ON q.id = eq.question_id
    WHERE eq.exam_id = @exam_id
    ORDER BY eq.sequence ASC, eq.id ASC;   
  `);

  const mappedQuestions = result.recordset.map(row => mapExamQuestionRow(row));
  return buildExamQuestionsResponse(exam, mappedQuestions);
}


// Lấy chi tiết 1 câu hỏi trong exam (GV)
export async function getQuestionInExamDetail(teacherId, examId, questionId) {
  const exam = await ensureExamOwnedByTeacher(teacherId, examId);

  const pool = await getPool();
  const request = pool.request();
  request.input('exam_id', sql.UniqueIdentifier, examId);
  request.input('question_id', sql.UniqueIdentifier, questionId);

  const result = await request.query(`
    SELECT
      eq.id              AS exam_question_id,
      eq.exam_id,
      eq.question_id,
      eq.points,
      eq.sequence,
      q.title,
      q.body,
      q.type,
      q.difficulty,
      q.choices,
      q.tags,
      q.image_s3_key, 
      q.audio_s3_key  
    FROM exam_questions eq
    JOIN questions q ON q.id = eq.question_id
    WHERE eq.exam_id = @exam_id
      AND eq.question_id = @question_id;
  `);

  if (result.recordset.length === 0) {
    const err = new Error('Question not found in this exam');
    err.status = 404;
    throw err;
  }

  const q = mapExamQuestionRow(result.recordset[0]);
  return buildExamQuestionsResponse(exam, [q]);
}

// Cập nhật câu hỏi trong exam (cả nội dung + điểm / thứ tự)
export async function updateQuestionInExam(
  teacherId,
  examId,
  questionId,
  payload
) {
  const exam = await ensureExamOwnedByTeacher(teacherId, examId);

  const { points, sequence, ...questionFields } = payload;

  const choicesJson = questionFields.choices
    ? JSON.stringify(questionFields.choices)
    : null;
  const tagsJson = questionFields.tags
    ? JSON.stringify(questionFields.tags)
    : null;

  const updatedQuestion = await updateQuestionById(questionId, {
    ...questionFields,
    choicesJson,
    tagsJson
  });

  if (!updatedQuestion) {
    const err = new Error('Question not found');
    err.status = 404;
    throw err;
  }

  const pool = await getPool();
  const request = pool.request();
  request.input('exam_id', sql.UniqueIdentifier, examId);
  request.input('question_id', sql.UniqueIdentifier, questionId);
  request.input(
    'points',
    sql.Decimal(6, 2),
    points != null ? points : 1
  );
  request.input(
    'sequence',
    sql.Int,
    sequence != null ? sequence : 0
  );

  const eqResult = await request.query(`
    UPDATE eq
    SET points = @points,
        sequence = @sequence
    OUTPUT inserted.*
    FROM exam_questions eq
    WHERE eq.exam_id = @exam_id AND eq.question_id = @question_id;
  `);

  if (eqResult.recordset.length === 0) {
    const err = new Error('Question not found in this exam');
    err.status = 404;
    throw err;
  }

  const eq = eqResult.recordset[0];

  const parsedChoices = updatedQuestion.choices
    ? JSON.parse(updatedQuestion.choices)
    : null;
  const parsedTags = updatedQuestion.tags
    ? JSON.parse(updatedQuestion.tags)
    : null;

  const questionItem = {
    questionId,
    title: updatedQuestion.title,
    body: updatedQuestion.body,
    type: updatedQuestion.type,
    difficulty: updatedQuestion.difficulty,
    choices: parsedChoices,
    tags: parsedTags,
    points: Number(eq.points ?? 1),
    sequence: eq.sequence
  };

  return buildExamQuestionsResponse(exam, [questionItem]);
}

// Xoá câu hỏi khỏi exam (và xoá luôn question nếu không còn dùng ở exam nào khác)
export async function deleteQuestionInExam(
  teacherId,
  examId,
  questionId
) {
  await ensureExamOwnedByTeacher(teacherId, examId);

  const pool = await getPool();

  // xoá link exam_questions
  await pool
    .request()
    .input('exam_id', sql.UniqueIdentifier, examId)
    .input('question_id', sql.UniqueIdentifier, questionId)
    .query(`
      DELETE FROM exam_questions
      WHERE exam_id = @exam_id AND question_id = @question_id;
    `);

  // nếu question không còn được dùng ở exam nào khác thì xoá luôn question
  const checkResult = await pool
    .request()
    .input('question_id', sql.UniqueIdentifier, questionId)
    .query(`
      SELECT COUNT(*) AS cnt
      FROM exam_questions
      WHERE question_id = @question_id;
    `);

  const count = Number(checkResult.recordset[0].cnt || 0);
  if (count === 0) {
    await deleteQuestionById(questionId);
  }
}

// Tạo bài kiểm tra
export async function createTeacherExam(teacherId, payload) {
  const exam = await createExam({
    courseId: payload.courseId || null,
    title: payload.title,
    description: payload.description,
    durationMinutes: payload.durationMinutes,
    passingScore: payload.passingScore,
    randomizeQuestions: payload.randomizeQuestions,
    createdBy: teacherId
  });

  return exam;
}

// Lấy chi tiết exam (cho giáo viên)
export async function getTeacherExamDetail(examId) {
  const exam = await getExamDetail(examId);
  if (!exam) return null;
  return parseExamQuestions(exam);
}

// List đề thi của giáo viên
export async function listTeacherExams(
  teacherId,
  { page, pageSize, search }
) {
  const exams = await getExamsByCreator({
    creatorId: teacherId,
    page,
    pageSize,
    search
  });
  return exams;
}

// (MỚI) List đề thi đã publish cho Member
export async function listMemberPublicExams(
  userId,
  { page, pageSize, search, courseId }
) {
  const exams = await getPublishedExamsForUser({
    page,
    pageSize,
    search,
    courseId
  });

  // hiện tại không filter theo enrollments, chỉ lấy tất cả exam publish.
  return exams;
}

// Cập nhật đề thi (meta, không sửa list câu hỏi)
export async function updateTeacherExam(teacherId, examId, payload) {
  const exam = await getExamDetail(examId);
  if (!exam) {
    const err = new Error('Exam not found');
    err.status = 404;
    throw err;
  }

  if (
    String(exam.created_by).toLowerCase() !==
    String(teacherId).toLowerCase()
  ) {
    const err = new Error('You are not allowed to update this exam');
    err.status = 403;
    throw err;
  }

  const updated = await updateExam({
    examId,
    courseId: payload.courseId || null,
    title: payload.title,
    description: payload.description,
    durationMinutes: payload.durationMinutes,
    passingScore: payload.passingScore,
    randomizeQuestions: payload.randomizeQuestions
  });

  return updated;
}

// Publish / unpublish đề
export async function publishTeacherExam(teacherId, examId, published) {
  const exam = await getExamDetail(examId);
  if (!exam) {
    const err = new Error('Exam not found');
    err.status = 404;
    throw err;
  }

  if (
    String(exam.created_by).toLowerCase() !==
    String(teacherId).toLowerCase()
  ) {
    const err = new Error('You are not allowed to publish this exam');
    err.status = 403;
    throw err;
  }

  const updated = await setExamPublished(examId, published);

  // NOTI: Nếu vừa publish và có course, gửi thông báo NEW_EXAM cho các học viên đã enroll
  if (published && updated.course_id) {
    const pool = await getPool();
    const enrollResult = await pool
      .request()
      .input('course_id', sql.UniqueIdentifier, updated.course_id)
      .query(`
        SELECT user_id
        FROM enrollments
        WHERE course_id = @course_id AND status = N'active';
      `);

    const userIds = enrollResult.recordset.map((r) => r.user_id);

    if (userIds.length > 0) {
      await createNotificationsForUsers({
        userIds,
        type: 'NEW_EXAM',
        payloadBuilder: () => ({
          examId: updated.id,
          examTitle: updated.title,
          courseId: updated.course_id
        })
      });
    }
  }

  return updated;
}

// Xoá đề thi
export async function deleteTeacherExam(teacherId, examId) {
  const exam = await getExamDetail(examId);
  if (!exam) {
    const err = new Error('Exam not found');
    err.status = 404;
    throw err;
  }

  if (
    String(exam.created_by).toLowerCase() !==
    String(teacherId).toLowerCase()
  ) {
    const err = new Error('You are not allowed to delete this exam');
    err.status = 403;
    throw err;
  }

  await deleteExamById(examId);
}

// ============================
// PHẦN HỌC SINH
// ============================

// Học sinh bấm Start để bắt đầu làm bài
export async function startStudentExam(studentId, examId) {
  const exam = await getExamDetail(examId);
  if (!exam) return null;

  // chỉ cho làm nếu exam đã publish
  if (!exam.published) {
    const err = new Error('Exam is not published');
    err.status = 400;
    throw err;
  }

  // Chuyển JSON choices/tags cho từng câu hỏi
  parseExamQuestions(exam);

  // Tạo 1 submission mới (DB tự set started_at = SYSDATETIMEOFFSET())
  const submission = await createSubmission({
    examId,
    userId: studentId,
    autoGraded: true
  });

  // ======= NOTIFICATION: EXAM_STARTED cho Teacher tạo đề =======
  if (exam.created_by) {
    await createNotification({
      userId: exam.created_by,
      type: 'EXAM_STARTED',
      payload: {
        examId: exam.id,
        examTitle: exam.title,
        courseId: exam.course_id,
        submissionId: submission.id,
        studentId
      }
    });
  }

  // ======= TÍNH THÔNG TIN THỜI GIAN =======
  const durationMinutes = exam.duration_minutes; // cột trong DB
  const durationSeconds =
    typeof durationMinutes === 'number' && durationMinutes > 0
      ? durationMinutes * 60
      : null;

  // started_at lấy từ DB
  let startedAt = submission.started_at;
  if (startedAt instanceof Date) {
    startedAt = startedAt.toISOString();
  } else if (startedAt && typeof startedAt === 'string') {
    startedAt = new Date(startedAt).toISOString();
  }

  let expiresAt = null;
  if (durationSeconds && startedAt) {
    const startDate = new Date(startedAt);
    expiresAt = new Date(
      startDate.getTime() + durationSeconds * 1000
    ).toISOString();
  }

  // Trả thêm startedAt, durationSeconds, expiresAt cho FE
  return {
    submissionId: submission.id,
    exam,
    startedAt,
    durationSeconds,
    expiresAt
  };
}

// ========== Logic chấm điểm từng câu ==========
function gradeSingleQuestion(question, answerPayload, questionPoints) {
  const type = question.type;
  const choices = question.choices || [];
  let awardedPoints = 0;
  let correct = false;

  // Choice-based questions: trắc nghiệm, true/false, image, audio...
  const isChoiceType = [
    'single_choice',
    'multiple_choice',
    'true_false',
    'true_false_ng',
    'image_choice',
    'audio_choice'
  ].includes(type);

  if (isChoiceType) {
    const correctIndexes = choices
      .map((c, idx) => (c.isCorrect ? idx : null))
      .filter((idx) => idx !== null);

    if (
      !answerPayload ||
      !Array.isArray(answerPayload.selectedOptionIndexes)
    ) {
      return { awardedPoints: 0, correct: false };
    }

    // bỏ trùng index nếu FE gửi thừa
    const selected = Array.from(
      new Set(answerPayload.selectedOptionIndexes.map((n) => Number(n)))
    ).filter((n) => !Number.isNaN(n));

    if (type === 'multiple_choice') {
      if (selected.length === 0) {
        return { awardedPoints: 0, correct: false };
      }

      const allCorrect = selected.every((idx) =>
        correctIndexes.includes(idx)
      );
      const noMissing = correctIndexes.every((idx) =>
        selected.includes(idx)
      );
      correct = allCorrect && noMissing;
      awardedPoints = correct ? questionPoints : 0;
      return { awardedPoints, correct };
    }

    // Các loại single choice
    if (selected.length !== 1 || correctIndexes.length === 0) {
      return { awardedPoints: 0, correct: false };
    }

    correct = selected[0] === correctIndexes[0];
    awardedPoints = correct ? questionPoints : 0;
    return { awardedPoints, correct };
  }

  // Short answer
  if (type === 'short_answer') {
    const cfg = question.choices || {};
    const correctAnswers = cfg.correctAnswers || [];
    const caseInsensitive = cfg.caseInsensitive;
    const trim = cfg.trim;

    let student = (answerPayload && answerPayload.text) || '';
    if (typeof student !== 'string') student = String(student);

    if (trim) {
      student = student.trim();
    }

    let compareList = correctAnswers.map((a) =>
      typeof a === 'string' ? a : String(a)
    );

    if (caseInsensitive) {
      student = student.toLowerCase();
      compareList = compareList.map((a) => a.toLowerCase());
    }

    if (compareList.includes(student)) {
      awardedPoints = questionPoints;
      correct = true;
    }

    return { awardedPoints, correct };
  }

  // Cloze (đục lỗ)
  if (type === 'cloze_single' || type === 'cloze_multiple') {
    const cfg = question.choices || {};
    const blanks = cfg.blanks || [];
    const ansBlanks = (answerPayload && answerPayload.blanks) || {};
    if (!Array.isArray(blanks) || blanks.length === 0) {
      return { awardedPoints: 0, correct: false };
    }

    let correctCount = 0;

    for (const blank of blanks) {
      const id = String(blank.id);
      const correctAnswers = (blank.correctAnswers || []).map((a) =>
        typeof a === 'string' ? a : String(a)
      );
      const caseInsensitive = blank.caseInsensitive;
      const trim = blank.trim;

      let student = ansBlanks[id] ?? '';
      if (typeof student !== 'string') student = String(student);

      if (trim) {
        student = student.trim();
      }

      let compareStudent = student;
      let compareList = correctAnswers;

      if (caseInsensitive) {
        compareStudent = student.toLowerCase();
        compareList = correctAnswers.map((a) => a.toLowerCase());
      }

      if (compareList.includes(compareStudent)) {
        correctCount += 1;
      }
    }

    const ratio = correctCount / blanks.length;
    awardedPoints = Math.round(questionPoints * ratio * 100) / 100;
    correct = ratio === 1;
    return { awardedPoints, correct };
  }

  // Loại không hỗ trợ auto-grade → 0 điểm
  return { awardedPoints: 0, correct: false };
}

// Chấm toàn bộ bài
function gradeStudentAnswers(exam, answers) {
  const answerMap = new Map();
  (answers || []).forEach((a) => {
    if (a && a.questionId) {
      answerMap.set(a.questionId, a.answer);
    }
  });

  const items = [];
  let totalScore = 0;
  let totalPointsPossible = 0;
  let correctCount = 0;
  const totalQuestions = exam.questions.length;

  for (const q of exam.questions) {
    const questionId = q.question_id;
    const questionPoints = Number(q.points || 1);
    totalPointsPossible += questionPoints;

    const answerPayload = answerMap.get(questionId);
    const { awardedPoints, correct } = gradeSingleQuestion(
      q,
      answerPayload,
      questionPoints
    );

    totalScore += awardedPoints;
    if (correct) correctCount += 1;

    items.push({
      questionId,
      answerJson: JSON.stringify(answerPayload ?? null),
      awardedPoints,
      graded: true
    });
  }

  const passingScore = Number(exam.passing_score ?? 0); // %
  const percentage =
    totalPointsPossible > 0
      ? (totalScore / totalPointsPossible) * 100
      : 0;
  const passed = percentage >= passingScore;

  const resultSummary = {
    totalQuestions,
    correctCount,
    totalScore,
    totalPointsPossible,
    percentage,
    passingScore,
    passed
  };

  return { items, totalScore, resultSummary };
}

// Học sinh nộp bài
export async function submitStudentExam(studentId, submissionId, payload) {
  const submission = await getSubmissionById(submissionId);
  if (!submission) {
    const err = new Error('Submission not found');
    err.status = 404;
    throw err;
  }

  // kiểm tra quyền sở hữu
  if (
    String(submission.user_id).toLowerCase() !==
    String(studentId).toLowerCase()
  ) {
    const err = new Error('You are not allowed to submit this exam');
    err.status = 403;
    throw err;
  }

  if (submission.status === 'completed') {
    const err = new Error('Submission already completed');
    err.status = 400;
    throw err;
  }

  const exam = await getExamDetail(submission.exam_id);
  if (!exam) {
    const err = new Error('Exam not found');
    err.status = 404;
    throw err;
  }

  // ========== TÍNH THỜI GIAN ĐÃ LÀM ==========
  const durationMinutes = exam.duration_minutes; // DB column
  const timeLimitSeconds =
    typeof durationMinutes === 'number' && durationMinutes > 0
      ? durationMinutes * 60
      : null;

  let elapsedSeconds = 0;
  let timeoutExceeded = false;

  if (submission.started_at && timeLimitSeconds) {
    const startedAt =
      submission.started_at instanceof Date
        ? submission.started_at
        : new Date(submission.started_at);

    const now = new Date();
    elapsedSeconds = Math.max(
      0,
      Math.floor((now.getTime() - startedAt.getTime()) / 1000)
    );

    if (elapsedSeconds > timeLimitSeconds) {
      timeoutExceeded = true;
    }
  }

  // Parse câu hỏi trước khi chấm
  parseExamQuestions(exam);

  const { items, totalScore, resultSummary } = gradeStudentAnswers(
    exam,
    payload.answers || []
  );

  // Ghi thêm thông tin thời gian vào resultSummary (sẽ được lưu JSON trong DB)
  resultSummary.timeLimitSeconds = timeLimitSeconds;
  resultSummary.elapsedSeconds = elapsedSeconds;
  resultSummary.timeoutExceeded = timeoutExceeded;

  await saveSubmissionGrading({
    submissionId,
    items,
    totalScore,
    resultSummary
  });

  // ===== NOTI: Gửi thông báo cho Member + Teacher =====
  // 1. Member – EXAM_RESULT
  await createNotification({
    userId: submission.user_id,
    type: 'EXAM_RESULT',
    payload: {
      examId: exam.id,
      examTitle: exam.title,
      submissionId,
      courseId: exam.course_id,
      totalScore,
      summary: resultSummary
    }
  });

  // 2. Teacher – NEW_SUBMISSION (người tạo đề)
  if (exam.created_by) {
    await createNotification({
      userId: exam.created_by,
      type: 'NEW_SUBMISSION',
      payload: {
        examId: exam.id,
        examTitle: exam.title,
        submissionId,
        studentId: submission.user_id,
        totalScore,
        summary: resultSummary
      }
    });
  }
  // ==========================================

  return {
    submissionId,
    totalScore,
    result: resultSummary
  };
}

// ============================
// LỊCH SỬ & REVIEW CHO HỌC SINH
// ============================

// Lịch sử bài làm của 1 học sinh
export async function listStudentSubmissions(studentId, { page, pageSize }) {
  const rows = await getSubmissionsByUser({
    userId: studentId,
    page,
    pageSize
  });

  return rows.map((r) => ({
    submissionId: r.id,
    examId: r.exam_id,
    examTitle: r.exam_title,
    totalScore: Number(r.total_score ?? 0),
    status: r.status,
    startedAt: r.started_at,
    submittedAt: r.submitted_at,
    summary: r.result ? JSON.parse(r.result) : null
  }));
}

// Review chi tiết 1 submission
export async function getSubmissionReview(submissionId, user) {
  const submission = await getSubmissionWithDetails(submissionId);
  if (!submission) return null;

  // Kiểm tra quyền: Member chỉ xem bài của mình.
  if (user && user.roleName === 'Member') {
    if (
      String(submission.user_id).toLowerCase() !==
      String(user.localUserId).toLowerCase()
    ) {
      const err = new Error('You are not allowed to view this submission');
      err.status = 403;
      throw err;
    }
  }
  // Admin/Teacher được phép xem tất cả

  const resultSummary = submission.result
    ? JSON.parse(submission.result)
    : null;

  const items = (submission.items || []).map((it) => ({
    questionId: it.question_id,
    title: it.title,
    body: it.body,
    type: it.type,
    choices: it.choices ? JSON.parse(it.choices) : null,
    tags: it.tags ? JSON.parse(it.tags) : null,
    studentAnswer: it.answer ? JSON.parse(it.answer) : null,
    awardedPoints: Number(it.awarded_points ?? 0),
    maxPoints: Number(it.points ?? 1),
    sequence: it.sequence
  }));

  return {
    submissionId: submission.id,
    examId: submission.exam_id,
    examTitle: submission.exam_title,
    totalScore: Number(submission.total_score ?? 0),
    submittedAt: submission.submitted_at,
    summary: resultSummary,
    items
  };
}
